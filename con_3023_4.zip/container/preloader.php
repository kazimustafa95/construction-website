<div id="preloader">
		<div class="t-circle">
			<div class="t-circle1 t-child"></div>
			<div class="t-circle2 t-child"></div>
			<div class="t-circle3 t-child"></div>
			<div class="t-circle4 t-child"></div>
			<div class="t-circle5 t-child"></div>
			<div class="t-circle6 t-child"></div>
			<div class="t-circle7 t-child"></div>
			<div class="t-circle8 t-child"></div>
			<div class="t-circle9 t-child"></div>
			<div class="t-circle10 t-child"></div>
			<div class="t-circle11 t-child"></div>
			<div class="t-circle12 t-child"></div>
		</div>
	</div>