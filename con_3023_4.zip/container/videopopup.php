<div class="video-popup">
    <div class="video-popup-overlay"></div>
    <div class="video-popup-content">
      <div class="video-popup-layer"></div>
      <div class="video-popup-container">
        <div class="video-popup-align">
          <div class="embed-responsive embed-responsive-16by9">
            <iframe class="embed-responsive-item" src="about:blank"></iframe>
          </div>
        </div>
        <div class="video-popup-close"></div>
      </div>
    </div>
  </div>