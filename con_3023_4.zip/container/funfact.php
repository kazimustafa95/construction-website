<section class="fun-factor2 section gray-bg fw-400">
      <div class="container">
        <div class="section-header type2">
          <h2>Take a Look Our Achievement</h2>
          <div class="sub-heading">We have Ten years of solid working experience of this field<br>
            that makes us a perfect construction company.</div>
        </div>
        <div class="row">
          <div class="col-md-4">
            <div class="single-factor2 text-center">
              <h2 class="factor-number2"><span class="counter">400</span>+</h2>
              <h3 class="factor-header2">Project Completed</h3>
            </div>
          </div>
          <div class="col-md-4">
            <div class="single-factor2 text-center">
              <h2 class="factor-number2"><span class="counter">25</span>M</h2>
              <h3 class="factor-header2">Clients Handled</h3>
            </div>
          </div>
          <div class="col-md-4">
            <div class="single-factor2 text-center">
              <h2 class="factor-number2"><span class="counter">250</span></h2>
              <h3 class="factor-header2">Award Won</h3>
            </div>
          </div>
        </div>
      </div>
    </section>