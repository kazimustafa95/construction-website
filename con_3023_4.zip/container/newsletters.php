<div class="subscribe-wrap">
      <div class="container">
        <h2>Subscribe to Get Our News, Update and Special Offer.</h2>
        <form class="mailchimp" action="https://storerepublic.us12.list-manage.com/subscribe/post?u=d227d8d335060b093084903d0&amp;id=9ba078ceb0">
          <input type="email" name="subscribe" id="subscriber-email" placeholder="Enter your Email" class="form-control">
          <button type="submit" id="subscribe-button" class="t-btn">Subscribe</button>
          <!-- SUBSCRIPTION SUCCESSFUL OR ERROR MESSAGES -->
          <h5 class="subscription-success"> . </h5>
          <h5 class="subscription-error"> . </h5>
          <label class="subscription-label" for="subscriber-email"></label>
        </form>
      </div>
    </div>