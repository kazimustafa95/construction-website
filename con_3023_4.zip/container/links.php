<!-- Meta Tags -->
<meta charset="utf-8">
  <meta http-equiv="x-ua-compatible" content="ie=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <meta name="author" content="ThemeServices">
  <meta name="description" content="">
  <meta name="keywords" content="">
  <!-- Page Title -->
  <!-- Favicon Icon -->
  <link rel="icon" href="img/icon.png">
  <!-- Stylesheets -->
  <link rel="stylesheet" href="css/bootstrap.min.css">
  <link rel="stylesheet" href="css/fontAwesome.min.css">
  <link rel="stylesheet" href="css/lineIcons.min.css">
  <link rel="stylesheet" href="css/owlCarousel.min.css">
  <link rel="stylesheet" href="css/animate.min.css">
  <link rel="stylesheet" href="css/style.css">

  <?php 
    $web_num = "+1 58 755 71577";
    $web_email = "info@ledcorholdings.com";
    $web_emails = "support@ledcorholdings.com";
    $web_add = "CN Tower, 10th Floor. 10004 104th Ave NW, Edmonton, AB T5J 0K1"; 
  ?>