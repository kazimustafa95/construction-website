<div class="dilog-box-wrap section bg-img text-center" data-src="img/fun-fact-bg.jpg">
  <div class="container">
    <div class="dilog-box">
      <!-- <h2>Trusted us by over 10,000 local businesses</h2> -->
      <h2>Join Us in Building a Better Future</h2>
      <p style="width:80%; margin:0 auto; line-height:1.5;">Are you seeking a trusted partner for your construction or building service project?  Then, what’s stopping you? Contact us today and discuss your vision with us.</p>
      <br><br>
      <div class="button-group">
        <div class="call-number"><?php echo $web_num;?></div>
        <a class='t-btn' href='contact.php'>Get A Quote</a>
      </div>
    </div>
  </div>
</div>